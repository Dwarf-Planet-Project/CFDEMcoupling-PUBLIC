rm -r 1 2 3 processor* 
rm -r log.* flowRate/ pMinMax/ UMinMax/ postProcessing/ inletPressure/


